(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,580177,t=>{"use strict";var a=t.i(699826);t.i(310144);var e=t.i(568968);let s=async t=>{let s=!1;try{s=!!(await (0,e.hydrateLocalSession)()).authUserId}catch{}(0,a.dispatchJsonRpcResponse)({payload:t,result:s})};t.s(["handler",0,s])}]);

//# sourceMappingURL=0p6vliys7ok9v.js.map